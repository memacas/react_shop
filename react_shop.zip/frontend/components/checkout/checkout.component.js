import React, { Component } from 'react';
import { BrowserRouter as Router, Link } from 'react-router-dom';
import Navbar from '../navbar/navbar.component';
import './checkout.component.css';

export default class Shop extends Component {
  render(){
    return (
        <div className="principal">
          <div className="dataContainer">
            <div className="checkoutDataContainer">
                  <Navbar></Navbar>
              <div className="mainCheckoutContainer">

                <div className="row show-hide-message">
                  <div></div>
                </div>

                <div className="checkoutContainer">
                  prueb de Checkout
                </div>
              </div>
            </div>
          </div>
        </div>
    )
  }
}
