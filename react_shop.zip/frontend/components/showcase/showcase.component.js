import React, { Component } from 'react';
import { BrowserRouter as Router, Link } from 'react-router-dom';
import axios from 'axios';
import Navbar from '../navbar/navbar.component';
import Product from './product.component';
import { ProductConsumer } from '../../context';
import './showcase.component.css';

export default class showcase extends Component {

  constructor(props){
    super(props);

    this.state = {products: []}

  }

  render(){

    return (
      <React.Fragment>
        <div className="principal">
          <div className="dataContainer">
            <div className="showcaseDataContainer">
                  <Navbar></Navbar>
              <div className="mainShowcaseContainer">

                <div className="row show-hide-message">
                  <div></div>
                </div>

                <div className="showcaseContainer">

                  <div className="row">
                    <div className="col-md-9">
                      <h1>Catálogo de productos</h1>
                    </div>
                    <div className="col-md-3">
                      <form>
                        <div className="form-group">
                          <label htmlFor="buscar">Qué estás buscando?</label>
                          <div>
                            <input className="form-control" type="text" name="buscar" />
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>{/* FIN DEL ROW DEL ENCABEZADO*/}

                  <div className="row lista-productos" style={{marginTop:20}}>
                    <ProductConsumer>
                      {(value) => {
                        console.log(value);
                        return value.products.map(product => {
                          return <Product key={product._id} product = {product} adicionarProducto = {value.adicionarProducto} />;
                        })
                      }}
                    </ProductConsumer>


                  </div>{/* FIN DEL ROW DE PRODUCTOS */}

                </div>

              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    )
  }
}
