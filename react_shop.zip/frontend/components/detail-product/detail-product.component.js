import React, { Component } from 'react';
import { BrowserRouter as Router, Link } from 'react-router-dom';
import axios from 'axios';
import Navbar from '../navbar/navbar.component';
import './detail-product.component.css';

export default class DetailProduct extends Component {

  constructor(props){
    super(props);

    this.state = {
      nombre: '',
      nombreFoto: '',
      descripcion: '',
      precio: '',
      stock: '',
      qty_escogida: 1
    }
  }

  componentDidMount(){
    axios.get('/product/detailProduct/' + this.props.match.params.id)
        .then(res => {
          if (res.data.success){
            this.setState({
              nombre: res.data.product.nombre,
              nombreFoto: res.data.product.nombreFoto,
              descripcion: res.data.product.descripcion,
              precio: res.data.product.precio,
              stock: res.data.product.stock
            });

            localStorage.setItem("nombreFoto", this.state.nombreFoto )
          }

        }).catch(function(err){
          console.log(err);
        });
  }

  render(){
    return (
      <React.Fragment>
        <div className="principal">
          <div className="dataContainer">
            <div className="detailProductDataContainer">
                  <Navbar></Navbar>
              <div className="mainDetailProductContainer">

                <div className="row show-hide-message">
                  <div></div>
                </div>

                <div className="detailProductContainer">


                <h1 className="page-header">{ this.state.nombre }</h1>

                <div className="row">
                  <div className="thumbnail col-md-6">
                  {this.state.nombreFoto &&
                    <img src={require("../../assets/images/" +localStorage.getItem("nombreFoto") )} alt={require("../../assets/images/" + this.state.nombreFoto)} style={{ maxHeight: '300px' }} />
                  }

                  </div>

                  <div className="col-md-6">
                    <div><h4>{ this.state.nombre }</h4></div>
                    <div><strong>Precio: </strong>{ this.state.precio }</div>
                    <div><strong>Unidades disponibles: </strong>{ this.state.stock }</div>
                  </div>

                </div>

                <div className="row">
                  <div className="col-lg-5">
                    <Link to="/showcase"><button type="button" name="button" className="btn btn-default">Atràs</button></Link>
                  </div>
                </div>


                </div>
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    )
  }
}
