import React, { Component } from 'react';
import { BrowserRouter as Router, Link, NavLink } from 'react-router-dom';

export default class Navbar extends Component {
  render(){
    return (
      <nav className="navbar navbar-inverse">
        <div className="container-fluid">
          <div className="navbar-header">
            <span className="navbar-brand" href="#">FruVer.com</span>
          </div>
          <ul className="nav navbar-nav navbar-right">

            <li><Link to="/showcase"><span className="glyphicon glyphicon-th"></span></Link></li>
            <li><Link to="/checkout" ><span className="glyphicon glyphicon-shopping-cart"><span  className="badge badge-pill badge-danger">5</span></span></Link></li>
            <li><a><span className="glyphicon glyphicon-inbox"></span></a></li>
            <li><Link to="/login"><span className="glyphicon glyphicon-log-out"></span></Link></li>

          </ul>
        </div>
      </nav>

    )
  }
}
