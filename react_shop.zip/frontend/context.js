import React, { Component } from 'react';
import axios from 'axios';
const ProductContext = React.createContext();

class ProductProvider extends Component {


  constructor(props){
    super(props);
  }

  state = {products: []};

  componentDidMount(){
        axios.get('/product/allProducts')
            .then(res => {
              if (res.data.success)
                this.setState({products: res.data.products});
            }).catch(function(err){
              console.log(err);
            });
  }

  adicionarProducto = (id) =>{
    console.log("aqui agregando productos " + id);
  }

  render(){
    return (
      <ProductContext.Provider value={{products: this.state.products,
                                      adicionarProducto: this.adicionarProducto
                                    }}
      >
        {this.props.children}
      </ProductContext.Provider>
    )
  }
}

const ProductConsumer = ProductContext.Consumer;

export {ProductProvider, ProductConsumer};
