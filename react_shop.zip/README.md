"# angular_shop"  git init git add README.md git commit -m "first commit" git remote add origin https://github.com/memacas/angular_shop.git git push -u origin master
"# angular_shop"  git init git add README.md git commit -m "first commit" git remote add origin https://github.com/memacas/angular_shop.git git push -u origin master
"# react_shop"  git init git add README.md git commit -m "first commit" git remote add origin https://github.com/memacas/react_shop.git git push -u origin master
"# react_shop"  git init git add README.md git commit -m "first commit" git remote add origin https://github.com/memacas/react_shop.git git push -u origin master
